
% Ibase = imread('Bae.jpg');
% Jbase = imread('Bbe.jpg');
% Idetail = imread('Aae.jpg');
% Jdetail = imread('Abe.jpg');
% 
% %Apply dwt  
% [LL1,HL1,LH1,HH1] = dwt2(Ibase,'haar');
% [LL2,HL2,LH2,HH2] = dwt2(Jbase,'haar');
% [LL3,HL3,LH3,HH3] = dwt2(Idetail,'haar');
% [LL4,HL4,LH4,HH4] = dwt2(Jdetail,'haar');
% 
% %Combine Base
% LLB=(LL1+LL2);
% HLB=(HL1+HL2);
% LHB=(LH1+LH2);
% HHB=(HH1+HH2);
% %Combine Detail
% LLD=(LL3+LL4);
% HLD=(HL3+HL4);
% LHD=(LH3+LH4);
% HHD=(HH3+HH4);
% 
% %Combine Detail and base to form an image
% Ll=(LLB+LLD)/2;
% Hl=(HLB+HLD)/2;
% Lh=(LHB+LHD)/2;
% Hh=(HHB+HHD)/2;
% 
% 
% %Apply inverse dwt 
% Z = idwt2(Ll,Hl,Lh,Hh,'haar'); 
% % Y = idwt2(LLD,HLD,LHD,HHD,'haar'); 
% 
% image = rgb2gray(uint8(Z));
%  figure(3); imshow(image);


% Code for NSST

Ibase = imread('Bae.tif');
Jbase = imread('Bbe.tif');
Idetail = imread('Dae.tif');
Jdetail = imread('Dbe.tif');

%Apply dwt  
[LL1,HL1,LH1,HH1] = swt2(Ibase,1,'sym2');
[LL2,HL2,LH2,HH2] = swt2(Jbase,1,'sym2');
[LL3,HL3,LH3,HH3] = swt2(Idetail,1,'sym2');
[LL4,HL4,LH4,HH4] = swt2(Jdetail,1,'sym2');

%fusion start
AfL = 0.5*(LL1+LL2+LL3+LL4);
D = (abs(HL1)-abs(HL2)-abs(HL3)-abs(HL4))>=0;
HfL = D.*HL1 +(~D).*HL2 + D.*HL3 +(~D).*HL4;
D = (abs(LH1)-abs(LH2)-abs(LH3)-abs(LH4))>=0;
VfL = D.*LH1 +(~D).*LH2 + D.*LH3 +(~D).*LH4;
D = (abs(HH1)-abs(HH2)-abs(HH3)-abs(HH4))>=0;
DfL = D.*HH1 +(~D).*HH2 + D.*HH3 +(~D).*HH4;


%Apply inverse dwt 
Z = iswt2(AfL,HfL,VfL,DfL,'sym2'); 
% Y = idwt2(LLD,HLD,LHD,HHD,'haar'); 

image = rgb2gray(uint8(Z));
 figure(3); imshow(image);










