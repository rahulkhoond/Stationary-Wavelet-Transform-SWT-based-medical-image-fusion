function [QABF,LABF,NABF1,API,SD,AG,entropyF,MIF,FS1,SF] =  Quantitative_Analysis(a1,a2,YY)
   x1 = im2uint8(a1);  % READ IMAGE 1
 %figure, imshow(x1);
%xy= mat2gray(Y2);
   x2 = im2uint8(a2);  % READ IMAGE 2
%figure, imshow(x2);
%xz= mat2gray(YY);
   x7 = im2uint8(YY);
xrcw  = x7; % READ FUSED IMAGE  
  

%%% Parameters for Petrovic Metrics Computation.
Td=10;       
wt_min=0.001;
P=1;        
Lg=1.5;     
Nrg=0.9999; 
kg=19;      
sigmag=0.5; 
Nra=0.9995; 
ka=22;      
sigmaa=0.5; 

%%% Edge Strength & Orientation.
[gvA,ghA]=sobel_fn(x1);
gA=sqrt(ghA.^2+gvA.^2);

[gvB,ghB]=sobel_fn(x2);
gB=sqrt(ghB.^2+gvB.^2);

[gvF,ghF]=sobel_fn(xrcw);
gF=sqrt(ghF.^2+gvF.^2);

%%% Relative Edge Strength & Orientation.
[p,q]=size(xrcw);
for ii=1:p
   for jj=1:q
      if(gA(ii,jj)==0 | gF(ii,jj)==0)
         gAF(ii,jj)=0;
      elseif(gA(ii,jj)>gF(ii,jj))
         gAF(ii,jj)=gF(ii,jj)/gA(ii,jj);
      else
         gAF(ii,jj)=gA(ii,jj)/gF(ii,jj);
      end
      if(gB(ii,jj)==0 | gF(ii,jj)==0)
         gBF(ii,jj)=0;      
      elseif(gB(ii,jj)>gF(ii,jj))
         gBF(ii,jj)=gF(ii,jj)/gB(ii,jj);
      else
         gBF(ii,jj)=gB(ii,jj)/gF(ii,jj);
      end
      if(gvA(ii,jj)==0 & ghA(ii,jj)==0)
         aA(ii,jj)=0;
      else
         aA(ii,jj)=atan(gvA(ii,jj)/ghA(ii,jj));
      end      
      if(gvB(ii,jj)==0 & ghB(ii,jj)==0)
         aB(ii,jj)=0;
      else
         aB(ii,jj)=atan(gvB(ii,jj)/ghB(ii,jj));
      end
      if(gvF(ii,jj)==0 & ghF(ii,jj)==0)
         aF(ii,jj)=0;
      else
         aF(ii,jj)=atan(gvF(ii,jj)/ghF(ii,jj));
      end      
   end
end
aAF=abs(abs(aA-aF)-pi/2)*2/pi;
aBF=abs(abs(aB-aF)-pi/2)*2/pi;


%%% Edge Preservation Coefficient.
QgAF=Nrg./(1+exp(-kg*(gAF-sigmag)));
QaAF=Nra./(1+exp(-ka*(aAF-sigmaa)));
QAF=sqrt(QgAF.*QaAF);
QgBF=Nrg./(1+exp(-kg*(gBF-sigmag)));
QaBF=Nra./(1+exp(-ka*(aBF-sigmaa)));
QBF=sqrt(QgBF.*QaBF);

%%% Total Fusion Performance (QABF).
wtA=wt_min*ones(p,q);
wtB=wt_min*ones(p,q);
cA=ones(p,q); cB=ones(p,q);
for ii=1:p
   for jj=1:q
      if(gA(ii,jj)>=Td)
         wtA(ii,jj)=cA(ii,jj)*gA(ii,jj)^Lg;
      end
      if(gB(ii,jj)>=Td)
         wtB(ii,jj)=cB(ii,jj)*gB(ii,jj)^Lg;
      end
   end
end
wt_sum=sum(sum(wtA+wtB));
QAF_wtsum=sum(sum(QAF.*wtA))/wt_sum;  %% Information Contributions of A.
QBF_wtsum=sum(sum(QBF.*wtB))/wt_sum;  %% Information Contributions of B.
QABF=QAF_wtsum+QBF_wtsum   %% QABF=sum(sum(QAF.*wtA+QBF.*wtB))/wt_sum -> Total Fusion Performance.

%%% Fusion Gain (QdeltaABF).
Qdelta=abs(QAF-QBF);
QCinfo=(QAF+QBF-Qdelta)/2;
QdeltaAF=QAF-QCinfo;
QdeltaBF=QBF-QCinfo;
QdeltaAF_wtsum=sum(sum(QdeltaAF.*wtA))/wt_sum;
QdeltaBF_wtsum=sum(sum(QdeltaBF.*wtB))/wt_sum;
QdeltaABF=QdeltaAF_wtsum+QdeltaBF_wtsum;   %% Total Fusion Gain.
QCinfo_wtsum=sum(sum(QCinfo.*(wtA+wtB)))/wt_sum;
QABF11=QdeltaABF+QCinfo_wtsum;              %% Total Fusion Performance.

%%% Fusion Loss (LABF).
rr=zeros(p,q);
for ii=1:p
   for jj=1:q
      if(gF(ii,jj)<=gA(ii,jj) | gF(ii,jj)<=gB(ii,jj))
         rr(ii,jj)=1;
      else
         rr(ii,jj)=0;
      end
   end
end
LABF=sum(sum(rr.*((1-QAF).*wtA+(1-QBF).*wtB)))/wt_sum

%%% Fusion Artifacts (NABF) by Petrovic.
for ii=1:p
   for jj=1:q
      if(gF(ii,jj)>gA(ii,jj) & gF(ii,jj)>gB(ii,jj))
         na1(ii,jj)=2-QAF(ii,jj)-QBF(ii,jj);
      else
         na1(ii,jj)=0;         
      end
   end
end
NABF1=sum(sum(na1.*(wtA+wtB)))/wt_sum

Td=10;       
wt_min=0.001;
P=1;        
Lg=1.5;     
Nrg=0.9999; 
kg=19;      
sigmag=0.5; 
Nra=0.9995; 
ka=22;      
sigmaa=0.5; 
%%
%%
%%% Edge Strength & Orientation.
[gvA,ghA]=sobel_fn(x1);
gA=sqrt(ghA.^2+gvA.^2);

[gvB,ghB]=sobel_fn(x2);
gB=sqrt(ghB.^2+gvB.^2);

[gvF,ghF]=sobel_fn(xrcw);
gF=sqrt(ghF.^2+gvF.^2);

%%% Relative Edge Strength & Orientation.
[p,q]=size(xrcw);
for ii=1:p
   for jj=1:q
      if(gA(ii,jj)==0 | gF(ii,jj)==0)
         gAF(ii,jj)=0;
      elseif(gA(ii,jj)>gF(ii,jj))
         gAF(ii,jj)=gF(ii,jj)/gA(ii,jj);
      else
         gAF(ii,jj)=gA(ii,jj)/gF(ii,jj);
      end
      if(gB(ii,jj)==0 | gF(ii,jj)==0)
         gBF(ii,jj)=0;      
      elseif(gB(ii,jj)>gF(ii,jj))
         gBF(ii,jj)=gF(ii,jj)/gB(ii,jj);
      else
         gBF(ii,jj)=gB(ii,jj)/gF(ii,jj);
      end
      if(gvA(ii,jj)==0 & ghA(ii,jj)==0)
         aA(ii,jj)=0;
      else
         aA(ii,jj)=atan(gvA(ii,jj)/ghA(ii,jj));
      end      
      if(gvB(ii,jj)==0 & ghB(ii,jj)==0)
         aB(ii,jj)=0;
      else
         aB(ii,jj)=atan(gvB(ii,jj)/ghB(ii,jj));
      end
      if(gvF(ii,jj)==0 & ghF(ii,jj)==0)
         aF(ii,jj)=0;
      else
         aF(ii,jj)=atan(gvF(ii,jj)/ghF(ii,jj));
      end      
   end
end
aAF=abs(abs(aA-aF)-pi/2)*2/pi;
aBF=abs(abs(aB-aF)-pi/2)*2/pi;
%%
%%
%%% Edge Preservation Coefficient.
QgAF=Nrg./(1+exp(-kg*(gAF-sigmag)));
QaAF=Nra./(1+exp(-ka*(aAF-sigmaa)));
QAF=sqrt(QgAF.*QaAF);
QgBF=Nrg./(1+exp(-kg*(gBF-sigmag)));
QaBF=Nra./(1+exp(-ka*(aBF-sigmaa)));
QBF=sqrt(QgBF.*QaBF);
%%
%%
%%% Total Fusion Performance (QABF).
wtA=wt_min*ones(p,q);
wtB=wt_min*ones(p,q);
cA=ones(p,q); cB=ones(p,q);
for ii=1:p
   for jj=1:q
      if(gA(ii,jj)>=Td)
         wtA(ii,jj)=cA(ii,jj)*gA(ii,jj)^Lg;
      end
      if(gB(ii,jj)>=Td)
         wtB(ii,jj)=cB(ii,jj)*gB(ii,jj)^Lg;
      end
   end
end
wt_sum=sum(sum(wtA+wtB));
QAF_wtsum=sum(sum(QAF.*wtA))/wt_sum;  %% Information Contributions of A.
QBF_wtsum=sum(sum(QBF.*wtB))/wt_sum;  %% Information Contributions of B.
QABF=QAF_wtsum+QBF_wtsum   %% QABF=sum(sum(QAF.*wtA+QBF.*wtB))/wt_sum -> Total Fusion Performance.

%%% Fusion Gain (QdeltaABF).
Qdelta=abs(QAF-QBF);
QCinfo=(QAF+QBF-Qdelta)/2;
QdeltaAF=QAF-QCinfo;
QdeltaBF=QBF-QCinfo;
QdeltaAF_wtsum=sum(sum(QdeltaAF.*wtA))/wt_sum;
QdeltaBF_wtsum=sum(sum(QdeltaBF.*wtB))/wt_sum;
QdeltaABF=QdeltaAF_wtsum+QdeltaBF_wtsum;      %% Total Fusion Gain.
QCinfo_wtsum=sum(sum(QCinfo.*(wtA+wtB)))/wt_sum;
QABF11=QdeltaABF+QCinfo_wtsum;                %% Total Fusion Performance.
%%
%%
%%% Fusion Loss (LABF).
rr=zeros(p,q);
for ii=1:p
   for jj=1:q
      if(gF(ii,jj)<=gA(ii,jj) | gF(ii,jj)<=gB(ii,jj))
         rr(ii,jj)=1;
      else
         rr(ii,jj)=0;
      end
   end
end
LABF=sum(sum(rr.*((1-QAF).*wtA+(1-QBF).*wtB)))/wt_sum
%%
%%
%%% Fusion Artifacts (NABF) by Petrovic.
for ii=1:p
   for jj=1:q
      if(gF(ii,jj)>gA(ii,jj) & gF(ii,jj)>gB(ii,jj))
         na1(ii,jj)=2-QAF(ii,jj)-QBF(ii,jj);
      else
         na1(ii,jj)=0;         
      end
   end
end
NABF1=sum(sum(na1.*(wtA+wtB)))/wt_sum
%%
%% image quality measure 
%%% Average Pixel Intensity (API) or Mean.
API=mean(xrcw(:))
%%
%% Standard Deviation (SD).
[p,q]=size(xrcw);
xrcwd=double(xrcw);
SD=sqrt(sum(sum((xrcwd-API).^2))/(p*q))
%%
%% Average Gradient (AG).
tmp1=[xrcwd(2:p,:);xrcwd(1,:)];
tmp2=[xrcwd(:,2:q) xrcwd(:,1)];
tmp=sqrt((xrcwd-tmp1).^2+(xrcwd-tmp2).^2);
AG=sum(tmp(:))/(p*q)
clear tmp1 tmp2 tmp
%%
%% Entropy of the Fused Image.
[p,q]=size(xrcw);
histF=imhist_fn(xrcw);
pdfF=histF/(p*q); %% p*q=sum(hist_out);
entropyF=0;
for ii=1:256
   if(pdfF(ii)~=0)
      entropyF=entropyF-pdfF(ii)*log2(pdfF(ii));
   end
end
entropyF
%%
%%
%%% Mutual Information (Cross Entropy) of Fused Image.
histA=imhist_fn(x1); pdfA=histA/(p*q);
histB=imhist_fn(x2); pdfB=histB/(p*q);
jpdfAF=joint_hist_fn(x1,xrcw)/(p*q); %% Joint Entropy.
jpdfBF=joint_hist_fn(x2,xrcw)/(p*q);
jpdfAB=joint_hist_fn(x1,x2)/(p*q);
MIAF=0; MIBF=0; MIAB=0;
[p,q]=size(jpdfAF);
for ii=1:p
   for jj=1:q
      if(jpdfAF(ii,jj)~=0)
         MIAF=MIAF+jpdfAF(ii,jj)*log2(jpdfAF(ii,jj)/(pdfA(ii)*pdfF(jj)));
      end
      if(jpdfBF(ii,jj)~=0)
         MIBF=MIBF+jpdfBF(ii,jj)*log2(jpdfBF(ii,jj)/(pdfB(ii)*pdfF(jj)));
      end
      if(jpdfAB(ii,jj)~=0)
         MIAB=MIAB+jpdfAB(ii,jj)*log2(jpdfAB(ii,jj)/(pdfA(ii)*pdfB(jj)));
      end         
   end
end
% MIAF,MIBF,MIAB;
MIF=MIAF+MIBF
clear histA histB histF
clear jpdfAF jpdfBF jpdfAB pdfA pdfB pdfF
%%
%%
%%% Fusion Symmetry.
FS1=2-abs((MIAF/(MIAF+MIBF))-0.5)
FS2=2-abs((MIBF/(MIAF+MIBF))-0.5);

%%
%%% Average Normalized Correlation.
% diffF=xrcw-API;
% meanA=mean(x1(:)); diffA=x1-meanA;
% meanB=mean(x2(:)); diffB=x2-meanB;
% rAF=sum(sum((diffA.*diffF)))/(sqrt(sum(sum(diffA.^2))*sum(sum(diffF.^2))));
% rBF=sum(sum((diffB.*diffF)))/(sqrt(sum(sum(diffB.^2))*sum(sum(diffF.^2))));
% corr=(rAF+rBF)/2
% clear diffA diffB diffF
%%
%%
%%% Spatial Frequency (SF).
[p,q]=size(xrcwd);
rf=sqrt(sum(sum((xrcwd(:,2:q)-xrcwd(:,1:q-1)).^2))/(p*q));
cf=sqrt(sum(sum((xrcwd(2:p,:)-xrcwd(1:p-1,:)).^2))/(p*q));
SF=sqrt(rf^2+cf^2)
clear tmp1 tmp2
     
end