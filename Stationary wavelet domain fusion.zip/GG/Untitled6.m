Il = double(imread('c01_1.tif')) / 255;
op= demo_enhance(Il);
imshow(op);