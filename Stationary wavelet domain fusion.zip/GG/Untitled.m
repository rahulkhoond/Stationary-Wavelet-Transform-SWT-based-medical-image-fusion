I=imread('dfsf.jpg');
imshow(I);


getimage=imgetfile();
x=imread(getimage);
figure(1); imshow(x); title('1024*1024 Image')
y=imresize(x,[512 512]);
figure(2); imshow(y); title('512*512 Resized Image');
[filename, pathname] = uiputfile('*.jpg', 'Save Picture as');
imwrite([y, filename, pathname]);