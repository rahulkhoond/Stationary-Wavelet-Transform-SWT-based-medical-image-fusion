ai=imread('baseb.tif');
op = demoenh(ai);
imshow(op);