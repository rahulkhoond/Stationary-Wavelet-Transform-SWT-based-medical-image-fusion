%%% Image Fusion using Details computed from Cross Bilteral Filter output.
%%% Details are obtained by subtracting original image by cross bilateral filter output.
%%% These details are used to find weights (Edge Strength) for fusing the images.
%%% Author : B. K. SHREYAMSHA KUMAR 

%%% Copyright (c) 2013 B. K. Shreyamsha Kumar 
%%% All rights reserved.

%%% Permission is hereby granted, without written agreement and without license or royalty fees, to use, copy, 
%%% modify, and distribute this code (the source files) and its documentation for any purpose, provided that the 
%%% copyright notice in its entirety appear in all copies of this code, and the original source of this code, 
%%% This should be acknowledged in any publication that reports research using this code. The research is to be 
%%% cited in the bibliography as:

%%% B. K. Shreyamsha Kumar, �Image fusion based on pixel significance using cross bilateral filter", Signal, Image 
%%% and Video Processing, pp. 1-12, 2013. (doi: 10.1007/s11760-013-0556-9)

close all;
clear all;
clc;

%%% Fusion Method Parameters.
cov_wsize=5;

%%% Bilateral Filter Parameters.
sigmas=0.1;  %%% Spatial (Geometric) Sigma. 1.8
sigmar=0.1; %%% Range (Photometric/Radiometric) Sigma.25 256/10
ksize=51;   %%% Kernal Size  (should be odd).

arr=['A';'B'];
for m=1:2
   string=arr(m);
    %inp_image=strcat('images\med256',string,'.jpg');
   %inp_image=strcat('images\office256',string,'.tif');
    inp_image=strcat('images\gun',string,'.PNG');

   x{m}=imread(inp_image);
   if(size(x{m},3)==3)
      x{m}=rgb2gray(x{m});
   end
end
[M,N]=size(x{m});

%%% Cross Bilateral Filter.
tic

cbf_out{1}=cross_bilateral_filt2Df(x{1},x{2},sigmas,sigmar,ksize);
detail{1}=double(x{1})-cbf_out{1};

 figure,imshow(detail{1})
cbf_out{2}= cross_bilateral_filt2Df(x{2},x{1},sigmas,sigmar,ksize);
detail{2}=double(x{2})-cbf_out{2};
 figure,imshow(detail{2})
 
 
 C1 = cov([D1(:) D2(:)]);
[V11, D11] = eig(C1);
if D11(1,1) >= D11(2,2)
  pca1 = V11(:,1)./sum(V11(:,1));
else  
  pca1 = V11(:,2)./sum(V11(:,2));
end
  
imf1 = pca1(1)*D1 + pca1(2)*D2;
 

          imf2=(0.5*A1+0.5*A2);
        
 
fuseimage=(double(imf1)+double(imf2));

toc
        figure, imshow((fuseimage), [])

 

%%% Fusion Rule (IEEE Conf 2011).
%xfused=cbf_ieeeconf2011f(x,detail,cov_wsize);

%toc

5xfused8=uint8(xfused);

%if(strncmp(inp_image,'gun',3))
   %figure,imagesc(x{1}),colormap gray
   %figure,imagesc(x{2}),colormap gray
   %figure,imagesc(xfused8),colormap gray
%else
 %  figure,imshow(x{1})
  % figure,imshow(x{2})   
 %  figure,imshow(xfused8)  
%end

% axis([140 239 70 169]) %%% Office.

%fusion_perform_fn(xfused8,x);
