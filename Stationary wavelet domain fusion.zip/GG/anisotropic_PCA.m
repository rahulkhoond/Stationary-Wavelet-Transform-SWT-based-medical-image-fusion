function [baseone,detailone,baseto,detailto] = newbasedetail(I1,I2)
       
  if size(I1,3)==3
 I1=rgb2gray(I1);
 end

 if size(I2,3)==3
 I2=rgb2gray(I2);
 end
 
%ANISOTROPIC DIFFUSION
 num_iter = 10;
   delta_t = 0.15;
   kappa = 30;
   option = 1;
   tic
   
   baseone = anisodiff2D(I1,num_iter,delta_t,kappa,option);

  baseto= anisodiff2D(I2,num_iter,delta_t,kappa,option);

 detailone=double(I1)-baseone;
 detailto=double(I2)-baseto;
%Detail
% figure, imshow(uint8(detailone));
% figure, imshow(uint8(detailto));
% %Base
% figure, imshow(uint8(baseone));
% figure, imshow(uint8(baseto));
end 