%% this code is written by "rahul khoond"
% paper published in "International journal of advance science and technology" 
% paper TITLE "Multi-Modal image fusion via integrated anisotropic diffusion in stationary wavelet transform"

% if you use this code please cite the above paper 

%% insert main input here 

addpath GG
a1= imread('c01_1.tif');
a2= imread('c01_2.tif');
[a,b,c,d]= newbasedetail(a1,a2);   % newbasedetail is ADF (anisotropic diffusion)
B1= cat(3,a,a,a);
D1= cat(3,b,b,b);
B2= cat(3,c,c,c);
D2= cat(3,d,d,d);

%% applying guided filter and obtained output is
opeb1= demoenh(B1);  % demoenh is function calling guided filter for enhancement

oped1= demoenh(D1);
opeb2= demoenh(B2);
oped2= demoenh(D2);

%% 
 Ibase   = rgb2gray(opeb1); 
 Jbase   = rgb2gray(opeb2); 
 Idetail =  rgb2gray(oped1);
 Jdetail =  rgb2gray(oped2); 
 
%% 
% % %Apply swt  
[LL1,HL1,LH1,HH1] = swt2(Ibase,1,'sym2');
[LL2,HL2,LH2,HH2] = swt2(Jbase,1,'sym2');
[LL3,HL3,LH3,HH3] = swt2(Idetail,1,'sym2');
[LL4,HL4,LH4,HH4] = swt2(Jdetail,1,'sym2');
% % %fusion start
AfL = 0.5*(LL1+LL2+LL3+LL4);
D = (abs(HL1)-abs(HL2)-abs(HL3)-abs(HL4))>=0;
HfL = D.*HL1 +(~D).*HL2 + D.*HL3 +(~D).*HL4;
D = (abs(LH1)-abs(LH2)-abs(LH3)-abs(LH4))>=0;
VfL = D.*LH1 +(~D).*LH2 + D.*LH3 +(~D).*LH4;
D = (abs(HH1)-abs(HH2)-abs(HH3)-abs(HH4))>=0;
DfL = D.*HH1 +(~D).*HH2 + D.*HH3 +(~D).*HH4;
% 
% 
%% Apply inverse swt 

Z = iswt2(AfL,HfL,VfL,DfL,'sym2'); 
% 

% 
% %%------------------------------- show output %%--------------------------------------------------------------
 figure, imshow(Z,[]);
% %---------------------**********-----------------------_______________________-------------------------
% 
% 
%% fusion parameters 

%function [QABF,LABF,NABF,NABF1]=objective_fusion_perform_fn(xrcw,x)

%%% objective_fusion_perform_fn: Computes the Objective Fusion Performance Parameters proposed by Petrovic

%%%
%%% Outputs:
%%% QABF -> Total information transferred from source images to fused image measure proposed by Petrovic
%%% LABF -> Total loss of information measure proposed by Petrovic
%%% NABF1 -> Fusion Artifacts measure proposed by Petrovic
%%% NABF -> Modified Fusion Artifacts measure proposed by B. K. Shreyamsha Kumar
q = Quantitative_Analysis(a1,a1,Z);


 